declare const TunnelNames: string[];
export default TunnelNames;
