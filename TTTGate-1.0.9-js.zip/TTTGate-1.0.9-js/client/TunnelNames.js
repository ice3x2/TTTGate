"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
const TunnelNames = ["Yeongwol", "Jecheon", "Dobong", "Seoul", "Seokgang", "Gwanak", "Daegwang", "Gangneung",
    "Okgu", "Anseong", "Dangjin", "Ganghwa", "Wolgot", "Ansan", "Tongyeong", "Wando", "Muan", "Guwol", "Gangjeong", "Yongmun", "Daejeon", "Uiryeong",
    "Namyeong", "Milyang", "Yangsan", "Donghae", "Samcheok", "Gimhae", "Jinju", "Yangyang", "Haeju", "Gamak", "Pyeongchang", "Inje", "Gangneung", "Chuncheon",
    "Hongcheon", "Yanggu", "Namyangyang", "Saeman-geum", "Ansan", "HighPass", "Cheonan", "Tongdosa", "Dobongsan", "AnseongPass", "Cheonggyesan", "Uiam", "Seongnam",
    "Gunja", "Daejeon", "Gyeryongsan", "Punggi", "Wolsan", "Daegu", "Gongdan", "Gyeongju", "Donghae", "Yangyang", "Jeongseon", "Taebaek", "Yeongwol", "Sokcho", "Songcheon",
    "Yeosu", "Mokpo", "Yeonggwang", "Gwangju", "Gangjin", "Jindo", "Mokpo", "Jeju", "Seogwipo", "Airport", "Hwasun", "Haenam", "Damyang", "Gokseong", "Suncheon", "Wando", "Yeosu",
    "Mokpo", "Gwangju", "Gangjin", "Jindo", "Mokpo", "Jeju", "Seogwipo", "Airport", "Hwasun", "Haenam", "Damyang", "Gokseong", "Suncheon", "Haeahn", "SeomjinRiver", "Daebul", "Sanwansan",
    "Geumgwang", "Yeonsu", "Sapaesan", "Suraksan", "Bulamsan"];
exports.default = TunnelNames;
