declare let ClientApp: {
    start(): void;
};
export default ClientApp;
