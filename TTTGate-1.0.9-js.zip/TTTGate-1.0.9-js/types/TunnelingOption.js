"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
exports.DEFAULT_KEY = void 0;
const DEFAULT_KEY = "hello-TTTGate";
exports.DEFAULT_KEY = DEFAULT_KEY;
