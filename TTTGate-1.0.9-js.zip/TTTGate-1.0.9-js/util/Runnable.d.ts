interface Runnable {
    run(): void;
}
export default Runnable;
