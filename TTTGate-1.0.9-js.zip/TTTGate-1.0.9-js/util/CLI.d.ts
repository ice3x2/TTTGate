declare class CLI {
    static readSimpleOptions: () => {
        [key: string]: string;
    };
}
export default CLI;
