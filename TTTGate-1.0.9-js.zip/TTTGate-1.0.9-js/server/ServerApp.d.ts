declare let ServerApp: {
    start(): Promise<void>;
};
export default ServerApp;
