
/*
  Module: HttpHandlerLite.ts
  - Ready-to-use HTTP/HTTPS & WebSocket handler
  - Path rewrite, header/body rewrite, CORS, WebSocket bypass
*/
import { HttpMessageParser, MessageInfo } from './HttpMessageParser';
import { HeadersMap, serializeHeaders, setHeader, removeHeader } from './HeaderUtils';
import { decompress, compress } from './Compressor';
import { SocketHandler } from '../../util/SocketHandler';
import {EndpointHandler, EndpointHttpHandler} from "../../types/EndpointHandler";
import SocketState from "../../util/SocketState";

export interface HttpOption {
    pathRewriteRules?: Array<{ from: string; to: string }>;
    customRequestHeaders?: HeadersMap;
    customResponseHeaders?: HeadersMap;
    cors?: boolean;
    bodyRewriteRules?: Array<{ from: string; to: string }>;
}

export class HttpHandlerLite {
    private parser = new HttpMessageParser();
    private isWebSocket = false;
    private option: HttpOption;
    private currentInfo?: MessageInfo;
    private currentHeaders?: HeadersMap;
    private bodyBuf: Buffer[] = [];

    private constructor(
        private socket: SocketHandler,
        option: HttpOption = {}
    ) {
        this.option = option;
        this.bindParser();
        // socket events will be wired via setter
    }

    /**
     * Factory to replace old HttpHandler
     */
    public static create(socket: SocketHandler, option: HttpOption = {}): HttpHandlerLite {
        return new HttpHandlerLite(socket, option);
    }

    /**
     * Assign socket event handler (after create)
     */
    /**
     * Assign socket event handler (after create)
     */
    public set onSocketEvent(
        handlerFn: (handler: EndpointHandler | EndpointHttpHandler,state: SocketState, data?: any) => void
    ) {
        this.socket.onSocketEvent = (_sock, socketState, data) => {
            // Forward event to user handler
            handlerFn(this, /*dataOrInfo as any,*/ socketState, undefined);
            // Continue HTTP parsing for Receive
            if (socketState === SocketState.Receive && !this.isWebSocket && Buffer.isBuffer(data)) {
                this.parser.write(data as Buffer);
            }
        };
    }

    private bindParser() {
        this.parser.on('header', ({ info, headers }) => this.onHeader(info, headers));
        this.parser.on('data', data => this.onData(data));
        this.parser.on('end', () => this.onEnd());
        this.parser.on('upgrade', () => this.onUpgrade());
        this.parser.on('error', err => this.onError(err));
    }

    private onHeader(info: MessageInfo, headers: HeadersMap) {
        this.currentInfo = info;
        this.currentHeaders = { ...headers };

        if (info.type === 'request') {
            // Path rewrite
            if (info.path) {
                for (const rule of this.option.pathRewriteRules ?? []) {
                    const re = new RegExp(rule.from);
                    if (re.test(info.path)) {
                        info.path = info.path.replace(re, rule.to);
                        break;
                    }
                }
            }
            Object.entries(this.option.customRequestHeaders ?? {}).forEach(
                ([name, vals]) => setHeader(headers, name, vals.join(','), true)
            );
        } else {
            Object.entries(this.option.customResponseHeaders ?? {}).forEach(
                ([name, vals]) => setHeader(headers, name, vals.join(','), true)
            );
            if (this.option.cors) {
                removeHeader(headers, 'access-control-allow-origin');
                setHeader(headers, 'Access-Control-Allow-Origin', '*');
            }
        }

        const firstLine = info.type === 'request'
            ? `${info.method} ${info.path} ${info.version}`
            : `${info.version} ${info.status} ${info.statusText}`;
        const headBlock = [firstLine, serializeHeaders(headers), '', ''].join('');
        this.socket.sendData(Buffer.from(headBlock), () => {});
    }

    private onData(chunk: Buffer) {
        if (this.currentInfo?.type === 'response' && this.option.bodyRewriteRules && this.currentHeaders) {
            this.bodyBuf.push(chunk);
        } else {
            this.socket.sendData(chunk, () => {});
        }
    }

    private onEnd() {
        if (this.currentInfo?.type === 'response' && this.bodyBuf.length) {
            let body = Buffer.concat(this.bodyBuf);
            const enc = this.currentHeaders?.['content-encoding']?.[0];
            body = decompress(body, enc);
            let text = body.toString();
            for (const rule of this.option.bodyRewriteRules ?? []) {
                text = text.replace(new RegExp(rule.from, 'g'), rule.to);
            }
            body = Buffer.from(text);
            body = compress(body, enc);
            this.socket.sendData(body, () => {});
            this.bodyBuf = [];
        }
        this.resetState();

        this.socket.end_();
    }

    private onUpgrade() {
        this.isWebSocket = true;
    }

    private onError(err: Error) {
        console.error('HTTP parsing error', err);
        this.socket.destroy();
    }

    private resetState() {
        this.isWebSocket = false;
        this.currentInfo = undefined;
        this.currentHeaders = undefined;
        this.bodyBuf = [];
    }

    /** Destroy underlying socket */
    public destroy(): void {
        this.socket.destroy();
    }

    /** Retrieve bundle data from underlying socket */
    public getBundle(key: string): any {
        return this.socket.getBundle(key);
    }
}
