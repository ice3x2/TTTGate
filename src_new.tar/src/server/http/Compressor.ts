
/*
  Module: Compressor.ts.ts
  - gzip/deflate 지원 (sync)
*/
import zlib from 'zlib';
export function compress(body: Buffer, encoding?: string): Buffer {
    if (!encoding) return body;
    switch (encoding.toLowerCase()) {
        case 'gzip': return zlib.gzipSync(body);
        case 'deflate': return zlib.deflateSync(body);
        default: return body;
    }
}
export function decompress(body: Buffer, encoding?: string): Buffer {
    if (!encoding) return body;
    switch (encoding.toLowerCase()) {
        case 'gzip': return zlib.gunzipSync(body);
        case 'deflate': return zlib.inflateSync(body);
        default: return body;
    }
}

