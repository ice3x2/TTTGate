
/*
  Module: HttpMessageParser.ts
  - EventEmitter 기반으로 header/data/end/error 이벤트 제공
  - content-length, chunked, upgrade 지원
*/
import { EventEmitter } from 'events';
import {HeadersMap, parseHeaders} from './HeaderUtils';

enum State { PARSING_HEADER, READING_BODY, READING_CHUNK_SIZE, READING_CHUNK_DATA, UPGRADE, END }

type MessageType = 'request' | 'response';
export interface MessageInfo {
    type: MessageType;
    method?: string;
    path?: string;
    version: string;
    status?: number;
    statusText?: string;
}

export class HttpMessageParser extends EventEmitter {
    private buffer = Buffer.alloc(0);
    private state = State.PARSING_HEADER;
    private info!: MessageInfo;
    private headers!: HeadersMap;
    private contentLength = 0;
    private chunkSize = 0;

    public write(chunk: Buffer) {
        this.buffer = Buffer.concat([this.buffer, chunk]);
        this.process();
    }

    private process() {
        try {
            if (this.state === State.PARSING_HEADER) {
                const idx = this.buffer.indexOf('\r\n\r\n');
                if (idx < 0) return;
                const headerBlock = this.buffer.slice(0, idx).toString();
                this.buffer = this.buffer.slice(idx + 4);

                const [firstLine, ...rest] = headerBlock.split(/\r\n/);
                this.parseFirstLine(firstLine);
                this.headers = parseHeaders(rest);

                // 헤더 이벤트
                this.emit('header', { info: this.info, headers: this.headers });

                // 본문 상태 전환
                const te = this.headers['transfer-encoding']?.[0];
                if (te?.toLowerCase() === 'chunked') {
                    this.state = State.READING_CHUNK_SIZE;
                } else if (this.headers['content-length']) {
                    this.contentLength = parseInt(this.headers['content-length'][0], 10);
                    this.state = this.contentLength > 0 ? State.READING_BODY : State.END;
                } else if (this.info.method === 'GET') {
                    this.state = State.END;
                }
            }

            // WebSocket 핸드셰이크 요청/응답인지 체크
            const connection = this.headers['connection']?.[0]?.toLowerCase() ?? '';
            const upgradeHeader = this.headers['upgrade']?.[0]?.toLowerCase() ?? '';
            if (
                (this.info.type === 'request'  && upgradeHeader === 'websocket' && connection.includes('upgrade')) ||
                (this.info.type === 'response' && this.info.status === 101 && upgradeHeader === 'websocket')
            ) {
                this.state = State.UPGRADE;
                this.emit('upgrade', this.info, this.headers);
                return;
            }
            // 업그레이드가 아닌 경우, 본문 처리

            if (this.state === State.READING_BODY) {
                if (this.buffer.length < this.contentLength) return;
                const body = this.buffer.slice(0, this.contentLength);
                this.buffer = this.buffer.slice(this.contentLength);
                this.emit('data', body);
                this.state = State.END;
            }

            while (this.state === State.READING_CHUNK_SIZE) {
                const idx = this.buffer.indexOf('\r\n');
                if (idx < 0) return;
                this.chunkSize = parseInt(this.buffer.slice(0, idx).toString(), 16);
                this.buffer = this.buffer.slice(idx + 2);
                if (this.chunkSize === 0) { this.state = State.END; break; }
                this.state = State.READING_CHUNK_DATA;
            }

            if (this.state === State.READING_CHUNK_DATA) {
                if (this.buffer.length < this.chunkSize + 2) return;
                const data = this.buffer.slice(0, this.chunkSize);
                this.buffer = this.buffer.slice(this.chunkSize + 2);
                this.emit('data', data);
                this.state = State.READING_CHUNK_SIZE;
            }

            if (this.state === State.UPGRADE) {
                // 업그레이드 이후엔 버퍼 전체 전달
                this.emit('data', this.buffer);
                this.buffer = Buffer.alloc(0);
            }

            if (this.state === State.END) {
                this.emit('end');
                this.state = State.PARSING_HEADER;
            }
        } catch (err) {
            this.emit('error', err);
        }
    }

    private parseFirstLine(line: string) {
        const parts = line.split(' ');
        if (parts[0].startsWith('HTTP/')) {
            this.info = { type: 'response', version: parts[0], status: +parts[1], statusText: parts.slice(2).join(' ') };
        } else {
            this.info = { type: 'request', method: parts[0], path: parts[1], version: parts[2] };
        }
    }
}

