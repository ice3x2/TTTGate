/*
  Module: HeaderUtils.ts
  - 파싱된 헤더를 Map<string,string[]> 으로 관리
  - 헤더 조회/추가/제거/직렬화 유틸
*/
export type HeadersMap = Record<string, string[]>;

export function parseHeaders(lines: string[]): HeadersMap {
    const headers: HeadersMap = {};
    for (const line of lines) {
        const idx = line.indexOf(':');
        if (idx < 0) continue;
        const name = line.slice(0, idx).trim().toLowerCase();
        const value = line.slice(idx + 1).trim();
        headers[name] = headers[name] || [];
        headers[name].push(value);
    }
    return headers;
}

export function serializeHeaders(headers: HeadersMap): string {
    return Object.entries(headers)
        .flatMap(([name, values]) =>
            values.map(v => `${name}: ${v}`)
        ).join('\r\n');
}

export function getHeaderValue(headers: HeadersMap, name: string): string | null {
    const key = name.toLowerCase();
    return headers[key]?.[0] ?? null;
}

export function setHeader(
    headers: HeadersMap,
    name: string,
    value: string,
    replace: boolean = true
): void {
    const key = name.toLowerCase();
    if (replace) headers[key] = [value];
    else (headers[key] = headers[key] || []).push(value);
}

export function removeHeader(headers: HeadersMap, name: string): void {
    delete headers[name.toLowerCase()];
}

